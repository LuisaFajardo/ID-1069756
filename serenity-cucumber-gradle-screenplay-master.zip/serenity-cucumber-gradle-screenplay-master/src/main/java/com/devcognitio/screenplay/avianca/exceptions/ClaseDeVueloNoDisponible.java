package com.devcognitio.screenplay.avianca.exceptions;

public class ClaseDeVueloNoDisponible extends AssertionError {

    public ClaseDeVueloNoDisponible(String message, Throwable cause) {
        super(message, cause);
    }
}
