package com.devcognitio.screenplay.avianca.model.busqueda;

public class BuscarVuelos {

    public static BuscarVuelosSoloIdaBuilder paraViajeDeSoloIda() {
        return new BuscarVuelosSoloIdaBuilder();
    }
}
